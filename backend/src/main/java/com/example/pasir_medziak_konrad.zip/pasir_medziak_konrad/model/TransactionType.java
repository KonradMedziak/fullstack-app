package com.example.pasir_medziak_konrad.model;

public enum TransactionType {
    INCOME,
    EXPENSE
}
