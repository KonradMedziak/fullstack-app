package com.example.pasir_medziak_konrad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaSiRMedziakKonradApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaSiRMedziakKonradApplication.class, args);
    }

}
